def func_b():
    print("Hello from func_b()")